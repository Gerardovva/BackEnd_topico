package org.gerardo.desafio.backendtopico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendtopicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
