package org.gerardo.desafio.backendtopico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendtopicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendtopicoApplication.class, args);
	}

}
